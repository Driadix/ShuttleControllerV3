#ifndef _TOF_SENSE_H_
#define _TOF_SENSE_H_

#include "Arduino.h"

// Define uart communication pins
#define TOF_RX_PIN  15
#define TOF_TX_PIN  16

// Redefine serial port name
#define TOF_UART Serial1

#define TOF_UART_BAUDRATE 921600
#define TOF_UART_BEGIN() TOF_UART.begin(TOF_UART_BAUDRATE, SERIAL_8N1, TOF_RX_PIN, TOF_TX_PIN)

#define TOF_FRAME_HEADER 0x57
#define TOF_FUNCTION_MARK 0x00

typedef struct {
  uint8_t id;
  uint32_t system_time;
  uint32_t dis;
  uint8_t dis_status;
  uint16_t signal_strength;
  uint8_t range_precision;
} TOF_Parameter;

void TOF_Active_Decoding();
void TOF_Inquire_Decoding(uint8_t id);

#endif
