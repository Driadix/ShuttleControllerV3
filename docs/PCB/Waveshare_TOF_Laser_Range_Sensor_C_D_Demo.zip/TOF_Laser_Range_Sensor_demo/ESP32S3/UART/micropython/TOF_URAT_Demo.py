from machine import UART
from time import sleep

TOF_FRAME_HEADER = 0x57
TOF_FUNCTION_MARK = 0x00

TOF_system_time = 0
TOF_distance = 0
TOF_status = 0
TOF_signal_strength = 0
TOF_range_precision = 0

TOF_rx_data = [0] * 16
TOF_tx_data = [0x57, 0x10, 0xff, 0xff, 0x00, 0xff, 0xff, 0x63]


class TOF_Sense():
    def __init__(self, baud=921600, TOF_TX=16, TOF_RX=15):
        self.TOF_peek = 0
        self.count_i = 0
        self.check_sum = 0

        self.ser = UART(1, baudrate=baud, tx=TOF_TX, rx=TOF_RX)
        while self.ser.read() != None:
            sleep(0.001)

    def TOF_Active_Decoding(self):
        if self.ser.any() > 0:
            self.TOF_peek = ord(self.ser.read(1))

            # Only accept 0x57 as a header while waiting for the first byte of a frame.
            if self.count_i == 0 and self.TOF_peek != TOF_FRAME_HEADER:
                self.check_sum = 0
                return

            TOF_rx_data[self.count_i] = self.TOF_peek
            self.count_i = self.count_i + 1

            if self.count_i >= len(TOF_rx_data):
                self.count_i = 0
                self.check_sum = 0
                for i in range(0, 15):
                    self.check_sum = (self.check_sum + TOF_rx_data[i]) & 0xFF

                if (TOF_rx_data[0] == TOF_FRAME_HEADER) and (TOF_rx_data[1] == TOF_FUNCTION_MARK) and (self.check_sum == TOF_rx_data[15]):
                    print("TOF id is: " + str(TOF_rx_data[3]))

                    TOF_system_time = TOF_rx_data[4] | TOF_rx_data[5] << 8 | TOF_rx_data[6] << 16 | TOF_rx_data[7] << 24
                    print("TOF system time is: " + str(TOF_system_time) + 'ms')

                    TOF_distance = (TOF_rx_data[8]) | (TOF_rx_data[9] << 8) | (TOF_rx_data[10] << 16)
                    print("TOF distance is: " + str(TOF_distance) + 'mm')

                    TOF_status = TOF_rx_data[11]
                    print("TOF status is: " + str(TOF_status))

                    TOF_signal_strength = TOF_rx_data[12] | TOF_rx_data[13] << 8
                    print("TOF signal strength is: " + str(TOF_signal_strength))

                    TOF_range_precision = TOF_rx_data[14]
                    print("TOF range precision is: " + str(TOF_range_precision))

                    print("")
                    while self.ser.read() != None:
                        sleep(0.001)
                else:
                    print("Verification failed.")
                self.check_sum = 0
        else:
            print("The serial port does not receive data.")

    def TOF_Inquire_Decoding(self, id):
        TOF_tx_data[4] = id
        TOF_tx_data[7] = id + 0x63

        while self.ser.read() != None:
            sleep(0.001)
        self.ser.write(bytearray(TOF_tx_data))
        sleep(0.015)
        TOF_rx_data = list(self.ser.read(16))

        for i in range(0, 15):
            self.check_sum = (self.check_sum + TOF_rx_data[i]) & 0xFF

        if (TOF_rx_data[0] == TOF_FRAME_HEADER) and (TOF_rx_data[1] == TOF_FUNCTION_MARK) and (self.check_sum == TOF_rx_data[15]):
            print("TOF id is: " + str(TOF_rx_data[3]))

            TOF_system_time = TOF_rx_data[4] | TOF_rx_data[5] << 8 | TOF_rx_data[6] << 16 | TOF_rx_data[7] << 24
            print("TOF system time is: " + str(TOF_system_time) + 'ms')

            TOF_distance = (TOF_rx_data[8]) | (TOF_rx_data[9] << 8) | (TOF_rx_data[10] << 16)
            print("TOF distance is: " + str(TOF_distance) + 'mm')

            TOF_status = TOF_rx_data[11]
            print("TOF status is: " + str(TOF_status))

            TOF_signal_strength = TOF_rx_data[12] | TOF_rx_data[13] << 8
            print("TOF signal strength is: " + str(TOF_signal_strength))

            TOF_range_precision = TOF_rx_data[14]
            print("TOF range precision is: " + str(TOF_range_precision))

            print("")
            while self.ser.read() != None:
                sleep(0.001)
        else:
            print("Verification failed.")
        self.check_sum = 0


if __name__ == "__main__":
    tof = TOF_Sense()
    try:
        while True:
            tof.TOF_Active_Decoding()
            # tof.TOF_Inquire_Decoding(0)
            sleep(0.02)
    except KeyboardInterrupt:
        print("Quit.")
