/*****************************************************************************
 * | File       :   TOF_Sense.cpp
 * | Author     :   Waveshare team
 * | Function   :   TOF drive function
 * | Info       :
 *----------------
 * | This version:  V1.0
 * | Date       :   2024-09-11
 * | Info       :   Basic version
 *
 ******************************************************************************/
#include "TOF_Sense.h"

TOF_Parameter TOF_0;              // Define a structure to store decoded data
uint8_t count_i = 0, count_j = 0; // Loop count variable
uint8_t check_sum = 0;            // Checksum
uint8_t rx_buf[16];               // Serial port receiving array

#if defined (__AVR_ATmega328P__)
SoftwareSerial TOF_UART(TOF_RX_PIN, TOF_TX_PIN); // Specify the software serial port pin
#endif

static bool TOF_Decode_Rx_Buffer(bool flush_uart, bool print_distance_validity)
{
    check_sum = 0;
    for (count_j = 0; count_j < 15; count_j++)
    {
        check_sum += rx_buf[count_j]; // Calculate the checksum and take the lowest byte
    }

    // Determine whether the decoding is correct
    if ((rx_buf[0] == TOF_FRAME_HEADER) && (rx_buf[1] == TOF_FUNCTION_MARK) && (check_sum == rx_buf[15]))
    {
        TOF_0.id = rx_buf[3];                                                                                                                                                  // ID of the TOF module
        TOF_0.system_time = (unsigned long)(((unsigned long)rx_buf[7]) << 24 | ((unsigned long)rx_buf[6]) << 16 | ((unsigned long)rx_buf[5]) << 8 | (unsigned long)rx_buf[4]); // The time after the TOF module is powered on
        TOF_0.dis = ((float)(((long)(((unsigned long)rx_buf[10] << 24) | ((unsigned long)rx_buf[9] << 16) | ((unsigned long)rx_buf[8] << 8))) / 256));                         // The distance output by the TOF module
        TOF_0.dis_status = rx_buf[11];                                                                                                                                         // Distance status indication output by TOF module
        TOF_0.signal_strength = (unsigned int)(((unsigned int)rx_buf[13] << 8) | (unsigned int)rx_buf[12]);                                                                    // The signal strength output by the TOF module
        TOF_0.range_precision = rx_buf[14];                                                                                                                                    // The repeatability accuracy reference value output by the TOF module

        // Print data through the terminal
        Serial.print("TOF id is:");Serial.println(TOF_0.id);
        Serial.print("TOF system time is:");Serial.println(TOF_0.system_time);
        Serial.print("TOF distance is:");Serial.println(TOF_0.dis);
        Serial.print("TOF status is:");Serial.println(TOF_0.dis_status);
        if (print_distance_validity)
        {
            if (TOF_0.dis_status == 0)
                Serial.println("Measurement distance is invalid.");
            else
                Serial.println("Measurement distance is valid.");
        }
        Serial.print("TOF signal strength is:");Serial.println(TOF_0.signal_strength);
        Serial.print("TOF range precision is:");Serial.println(TOF_0.range_precision);
        Serial.println();

        if (flush_uart)
        {
            while (TOF_UART.read() >= 0); // Clear the serial port buffer
        }
        check_sum = 0;
        return true;
    }

    Serial.println("Verification failed.");
    check_sum = 0;
    return false;
}

static void TOF_Process_Active_Byte(uint8_t rx_data, bool flush_uart)
{
    // Only accept 0x57 as a header while waiting for the first byte of a frame.
    if (count_i == 0 && rx_data != TOF_FRAME_HEADER)
    {
        return;
    }

    rx_buf[count_i] = rx_data;
    count_i++;

    if (count_i >= sizeof(rx_buf))
    {
        count_i = 0;
        TOF_Decode_Rx_Buffer(flush_uart, false);
    }
}

/******************************************************************************
function:   Actively acquire TOF data and decode it
parameter:
Info:
******************************************************************************/
void TOF_Active_Decoding()
{
  while (TOF_UART.available() > 0)
  {
    int data = TOF_UART.read();
    if (data < 0)
    {
        return;
    }

    TOF_Process_Active_Byte((uint8_t)data, true);
  }
}

uint8_t tx_buf[8] = {0x57,0x10,0xff,0xff,0x00,0xff,0xff,0x63}; // Query the command with ID 0

/******************************************************************************
function:   Get TOF data by querying and decoding
parameter:
Info:
******************************************************************************/
void TOF_Inquire_Decoding(uint8_t id)
{
    uint8_t num = 0;
    tx_buf[4] = id;        // Add the ID you want to query to the command
    tx_buf[7] = id + 0x63; // Update Checksum
    while (TOF_UART.read() >= 0); // Clear the serial port buffer
    TOF_UART.write(tx_buf,8);     // Start query
    delay(15);                    // Waiting for the sensor to return data

    while (TOF_UART.available() && num < sizeof(rx_buf))
    {
        int data = TOF_UART.read();
        if (data < 0)
        {
            break;
        }
        rx_buf[num++] = (uint8_t)data;
    }

    if (num < sizeof(rx_buf))
    {
        Serial.println("Verification failed.");
        check_sum = 0;
        return;
    }

    TOF_Decode_Rx_Buffer(false, true);
}
