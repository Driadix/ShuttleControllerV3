#ifndef _TOF_SENSE_H_
#define _TOF_SENSE_H_

#include "Arduino.h"

#if defined (__AVR_ATmega328P__)
  #include <SoftwareSerial.h>

  // Define uart communication pins
  #define TOF_RX_PIN  10
  #define TOF_TX_PIN  11

  extern SoftwareSerial TOF_UART;
#else
  #define TOF_UART Serial1
#endif

#define TOF_UART_BAUDRATE 115200
#define TOF_UART_BEGIN() TOF_UART.begin(TOF_UART_BAUDRATE)

#define TOF_FRAME_HEADER 0x57
#define TOF_FUNCTION_MARK 0x00

typedef struct {
  uint8_t id;
  uint32_t system_time;
  uint32_t dis;
  uint8_t dis_status;
  uint16_t signal_strength;
  uint8_t range_precision;
} TOF_Parameter;

void TOF_Active_Decoding();
void TOF_Inquire_Decoding(uint8_t id);

#endif
