#include "TOF_Sense.h"

void setup() {
  Serial.begin(115200);
  while (!Serial && millis() < 3000) {
    delay(10);
  }
  TOF_UART_BEGIN();
}

void loop() {
  TOF_Active_Decoding();
  // TOF_Inquire_Decoding(0);
  delay(20);
}
