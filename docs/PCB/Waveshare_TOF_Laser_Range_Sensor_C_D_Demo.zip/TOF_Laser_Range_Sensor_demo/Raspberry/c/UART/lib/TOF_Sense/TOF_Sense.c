/*****************************************************************************
 * | File       :   TOF_Sense.c
 * | Author     :   Waveshare team
 * | Function   :   TOF drive function
 * | Info       :
 *----------------
 * | This version:  V1.0
 * | Date       :   2024-09-11
 * | Info       :   Basic version
 *
 ******************************************************************************/
#include "TOF_Sense.h"

TOF_Parameter TOF_0;              // Define a structure to store decoded data
uint8_t count_i = 0, count_j = 0; // Loop count variable
uint8_t check_sum = 0;            // Checksum
uint8_t rx_buf[16];               // Serial port receiving array
uint8_t TOF_peek = 0;             // Temporary storage of data

/******************************************************************************
function:   Actively acquire TOF data and decode it
parameter:
Info:
******************************************************************************/
void TOF_Active_Decoding()
{
    TOF_peek = UART_Read_Byte();

    // Only accept 0x57 as a header while waiting for the first byte of a frame.
    if (count_i == 0 && TOF_peek != TOF_FRAME_HEADER)
    {
        return;
    }

    rx_buf[count_i] = TOF_peek;
    count_i++;

    if (count_i >= sizeof(rx_buf))
    {
        count_i = 0;
        check_sum = 0;
        for (count_j = 0; count_j < 15; count_j++)
        {
            check_sum += rx_buf[count_j]; // Calculate the checksum and take the lowest byte
        }

        // Determine whether the decoding is correct
        if ((rx_buf[0] == TOF_FRAME_HEADER) && (rx_buf[1] == TOF_FUNCTION_MARK) && (check_sum == rx_buf[15]))
        {
            TOF_0.id = rx_buf[3];                                                                                                                                                  // ID of the TOF module
            TOF_0.system_time = (unsigned long)(((unsigned long)rx_buf[7]) << 24 | ((unsigned long)rx_buf[6]) << 16 | ((unsigned long)rx_buf[5]) << 8 | (unsigned long)rx_buf[4]); // The time after the TOF module is powered on
            TOF_0.dis = ((float)(((long)(((unsigned long)rx_buf[10] << 24) | ((unsigned long)rx_buf[9] << 16) | ((unsigned long)rx_buf[8] << 8))) / 256));                         // The distance output by the TOF module
            TOF_0.dis_status = rx_buf[11];                                                                                                                                         // Distance status indication output by TOF module
            TOF_0.signal_strength = (unsigned int)(((unsigned int)rx_buf[13] << 8) | (unsigned int)rx_buf[12]);                                                                    // The signal strength output by the TOF module
            TOF_0.range_precision = rx_buf[14];                                                                                                                                    // Repeatability accuracy reference value

            // Print data through the terminal
            printf("TOF id is:%d\r\n", TOF_0.id);
            printf("TOF system time is:%d ms\r\n", TOF_0.system_time);
            printf("TOF distance is:%d mm\r\n", TOF_0.dis);
            printf("TOF status is:%d\r\n", TOF_0.dis_status);
            printf("TOF signal strength is:%d\r\n", TOF_0.signal_strength);
            printf("TOF range precision is:%d\r\n\n", TOF_0.range_precision);
            UART_flushInput(); // Clear the serial port buffer
        }
        else
        {
            printf("Verification failed.\r\n");
        }
        check_sum = 0; // Clear Checksum
    }
}

uint8_t tx_buf[8] = {0x57,0x10,0xff,0xff,0x00,0xff,0xff,0x63}; // Query the command with ID 0

/******************************************************************************
function:   Get TOF data by querying and decoding
parameter:
Info:
******************************************************************************/
void TOF_Inquire_Decoding(uint8_t id)
{
    tx_buf[4] = id;        // Add the ID you want to query to the command
    tx_buf[7] = id + 0x63; // Update Checksum

    UART_flushInput();       // Clear the serial port buffer
    UART_Write_nByte(tx_buf,8); // Start query
    DEV_Delay_ms(10);        // Waiting for the sensor to return data
    UART_Read_nByte(rx_buf,16); // Reading sensor data
    for (count_j = 0; count_j < 15; count_j++)
    {
        check_sum += rx_buf[count_j]; // Calculate the checksum and take the lowest byte
    }
    // Determine whether the decoding is correct
    if ((rx_buf[0] == TOF_FRAME_HEADER) && (rx_buf[1] == TOF_FUNCTION_MARK) && (check_sum == rx_buf[15]))
    {
        TOF_0.id = rx_buf[3];                                                                                                                                                  // ID of the TOF module
        TOF_0.system_time = (unsigned long)(((unsigned long)rx_buf[7]) << 24 | ((unsigned long)rx_buf[6]) << 16 | ((unsigned long)rx_buf[5]) << 8 | (unsigned long)rx_buf[4]); // The time after the TOF module is powered on
        TOF_0.dis = ((float)(((long)(((unsigned long)rx_buf[10] << 24) | ((unsigned long)rx_buf[9] << 16) | ((unsigned long)rx_buf[8] << 8))) / 256));                         // The distance output by the TOF module
        TOF_0.dis_status = rx_buf[11];                                                                                                                                         // Distance status indication output by TOF module
        TOF_0.signal_strength = (unsigned int)(((unsigned int)rx_buf[13] << 8) | (unsigned int)rx_buf[12]);                                                                    // The signal strength output by the TOF module
        TOF_0.range_precision = rx_buf[14];                                                                                                                                    // Repeatability accuracy reference value

        // Print data through the terminal
        printf("TOF id is:%d\r\n", TOF_0.id);
        printf("TOF system time is:%d ms\r\n", TOF_0.system_time);
        printf("TOF distance is:%d mm\r\n", TOF_0.dis);
        printf("TOF status is:%d\r\n", TOF_0.dis_status);
        if (TOF_0.dis_status == 0)
            printf("Measurement distance is invalid.\r\n");
        else
            printf("Measurement distance is valid.\r\n");
        printf("TOF signal strength is:%d\r\n", TOF_0.signal_strength);
        printf("TOF range precision is:%d\r\n\n", TOF_0.range_precision);
    }
    else
    {
        printf("Verification failed.\r\n");
    }
    check_sum = 0; // Clear Checksum
}
