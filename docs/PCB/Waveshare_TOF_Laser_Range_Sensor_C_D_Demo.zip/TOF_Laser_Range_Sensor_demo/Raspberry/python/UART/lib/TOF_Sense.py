# /*****************************************************************************
# * | File        :   tof_sense.py
# * | Author      :   Waveshare team
# * | Function    :   TOF drive function
# * | Info        :
# *----------------
# * | This version:   V1.0
# * | Date        :   2024-09-11
# * | Info        :
# ******************************************************************************
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documnetation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to  whom the Software is
# furished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#

import serial
import time

TOF_FRAME_HEADER = 0x57
TOF_FUNCTION_MARK = 0x00

TOF_system_time = 0
TOF_distance = 0
TOF_status = 0
TOF_signal_strength = 0
TOF_range_precision = 0

TOF_rx_data = [0] * 16
TOF_tx_data = [0x57, 0x10, 0xff, 0xff, 0x00, 0xff, 0xff, 0x63]


class TOF_Sense():
    def __init__(self, dev='/dev/ttyS0', baud=921600):
        self.TOF_peek = 0
        self.count_i = 0
        self.check_sum = 0
        self.ser = serial.Serial(dev, baud)
        self.ser.flushInput()

    def TOF_Active_Decoding(self):
        if self.ser.inWaiting() > 0:
            self.TOF_peek = ord(self.ser.read(1))

            # Only accept 0x57 as a header while waiting for the first byte of a frame.
            if self.count_i == 0 and self.TOF_peek != TOF_FRAME_HEADER:
                self.check_sum = 0
                return

            TOF_rx_data[self.count_i] = self.TOF_peek
            self.count_i = self.count_i + 1

            if self.count_i >= len(TOF_rx_data):
                self.count_i = 0
                self.check_sum = 0
                for i in range(0, 15):
                    self.check_sum = (self.check_sum + TOF_rx_data[i]) & 0xFF

                if (TOF_rx_data[0] == TOF_FRAME_HEADER) and (TOF_rx_data[1] == TOF_FUNCTION_MARK) and (self.check_sum == TOF_rx_data[15]):
                    print("TOF id is: " + str(TOF_rx_data[3]))

                    TOF_system_time = TOF_rx_data[4] | TOF_rx_data[5] << 8 | TOF_rx_data[6] << 16 | TOF_rx_data[7] << 24
                    print("TOF system time is: " + str(TOF_system_time) + 'ms')

                    TOF_distance = (TOF_rx_data[8]) | (TOF_rx_data[9] << 8) | (TOF_rx_data[10] << 16)
                    print("TOF distance is: " + str(TOF_distance) + 'mm')

                    TOF_status = TOF_rx_data[11]
                    print("TOF status is: " + str(TOF_status))

                    TOF_signal_strength = TOF_rx_data[12] | TOF_rx_data[13] << 8
                    print("TOF signal strength is: " + str(TOF_signal_strength))

                    TOF_range_precision = TOF_rx_data[14]
                    print("TOF range precision is: " + str(TOF_range_precision))

                    print("")
                    self.ser.flushInput()
                else:
                    print("Verification failed.")
                self.check_sum = 0
        else:
            print("The serial port does not receive data.")

    def TOF_Inquire_Decoding(self, id):
        TOF_tx_data[4] = id
        TOF_tx_data[7] = id + 0x63

        self.ser.flushInput()
        self.ser.write(bytearray(TOF_tx_data))
        time.sleep(0.01)
        TOF_rx_data = list(self.ser.read(16))

        for i in range(0, 15):
            self.check_sum = (self.check_sum + TOF_rx_data[i]) & 0xFF

        if (TOF_rx_data[0] == TOF_FRAME_HEADER) and (TOF_rx_data[1] == TOF_FUNCTION_MARK) and (self.check_sum == TOF_rx_data[15]):
            print("TOF id is: " + str(TOF_rx_data[3]))

            TOF_system_time = TOF_rx_data[4] | TOF_rx_data[5] << 8 | TOF_rx_data[6] << 16 | TOF_rx_data[7] << 24
            print("TOF system time is: " + str(TOF_system_time) + 'ms')

            TOF_distance = (TOF_rx_data[8]) | (TOF_rx_data[9] << 8) | (TOF_rx_data[10] << 16)
            print("TOF distance is: " + str(TOF_distance) + 'mm')

            TOF_status = TOF_rx_data[11]
            print("TOF status is: " + str(TOF_status))

            TOF_signal_strength = TOF_rx_data[12] | TOF_rx_data[13] << 8
            print("TOF signal strength is: " + str(TOF_signal_strength))

            TOF_range_precision = TOF_rx_data[14]
            print("TOF range precision is: " + str(TOF_range_precision))

            print("")
            self.ser.flushInput()
        else:
            print("Verification failed.")
        self.check_sum = 0
